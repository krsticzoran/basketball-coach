export default function GalleryLayout({ gallery }) {
  return <>{gallery}</>
}
